/*Transformando com map() 
Crie um vetor com números e gere um novo vetor com o dobro de cada  valor usando map().*/

let num = [2, 8, 10, 16, 20]

let dobro = num.map(num => num * 2)

console.log(dobro)