/*Concatenando vetores 
Crie dois vetores (a e b) com números diferentes e junte-os em um único  vetor (c) usando concat(). 
*/

let num1 = [2, 8, 10, 16, 20]
let num2 = [1, 7, 9, 15, 19]

let num = num1.concat(num2)

console.log(num)