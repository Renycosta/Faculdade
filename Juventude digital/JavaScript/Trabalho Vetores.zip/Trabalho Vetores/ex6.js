/*Adicionando e removendo elementos 
Crie um vetor com 3 cores. 
Depois: 
o adicione uma cor no final com push(); 
o remova a primeira com shift(); 
o exiba o vetor final no console. */

let cor = ["amarelo", "azul", "vermelho"]

cor.push("rosa")
cor.shift("amarelo")

console.log(cor)