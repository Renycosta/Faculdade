/*Invertendo a ordem 
Crie um vetor com 5 números e exiba o vetor invertido (use reverse()).*/

let num = [2, 8, 10, 16, 20]

num.reverse()

console.log(num)