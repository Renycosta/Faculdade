/*Criação de vetor simples
Crie um vetor com 5 nomes de frutas e exiba cada um deles no console
usando um loop for.*/

const fruta = ["banana", "Maça", "Kiwi", "Uva", "Pera"]

for(let i = 0; i < fruta.length; i++){
    console.log(fruta[i])
}