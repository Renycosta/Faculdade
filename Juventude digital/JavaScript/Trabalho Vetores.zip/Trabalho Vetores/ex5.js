/*Filtrando valores 
Dado um vetor com números de 1 a 20, use o método filter() para criar um  novo vetor apenas com números maiores que 10.*/

let num = [1, 3, 15, 16, 8, 19, 1, 12, 4, 6, 18, 10, 20,]

let total = num.filter(num => num > 10);

console.log(total)