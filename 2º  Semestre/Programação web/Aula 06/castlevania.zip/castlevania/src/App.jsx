import { useState } from 'react'
 import { useForm } from 'react-hook-form'
 import './App.css'

 function App() {
  const { register, handleSubmit } = useForm()
  const [resposta, setResposta] = useState("")
  const [situacao, setSituacao] = useState("")
  const [total, setTotal] = useState (null)
  const [titulo, setTitulo] = useState ("")
  const [img, setImg] = useState ("")
  const [div, setDiv] = useState ("nada")

  function aleatorio(){
    const num = Math.ceil(Math.random()*5)
    setTotal(num)
    setDiv("div")
    setResposta("")
    setSituacao("")

    if(num == 1){
      setTitulo("Aria of Sorrow")
      setImg("./img/aria.jpg")
    }else if(num == 2){
      setTitulo("Bloodlines")
      setImg("./img/bloodlines.png")
    }else if(num == 3){
      setTitulo("Order of Ecclesia")
       setImg("./img/order.jpg")
    }else if (num == 4){
      setTitulo("Rondo of blood")
      setImg("./img/rondo.png")
    }else{
      setTitulo("Symphony of the night")
      setImg("./img/symphony.jpg")
    }
  }

  function info(data){
    const nome = data.nome
    const plataforma = data.plataforma
    const vendido = data.vendido
    const ano = data.ano
    const genêro = data.genêro

    let val = 0
    if(total == 1){
     if(nome == "Soma"){val++}
      if(plataforma == "Game-boy"){val++}
      if(vendido == "Não"){val++}
      if(ano == "2003"){val++}
      if(genêro == "metroidvania"){val++}
    }else if(total ==2){
      if(nome == "John"){val++}
      if(plataforma == "Mega-Drive"){val++}
      if(vendido == "Não"){val++}
      if(ano == "1994"){val++}
      if(genêro == "classicvania"){val++}
    }else if(total == 3){
      if(nome == "Shanoa"){val++}
      if(plataforma == "DS"){val++}
      if(vendido == "Não"){val++}
      if(ano == "2008"){val++}
      if(genêro == "metroidvania"){val++}
    }else if(total == 4){
      if(nome == "Richter"){val++}
      if(plataforma == "TurboGrafx-16"){val++}
      if(vendido == "Não"){val++}
      if(ano == "1993"){val++}
      if(genêro == "classicvania"){val++}
    }else if(total == 5){
      if(nome == "Alucard"){val++}
      if(plataforma == "PS1"){val++}
      if(vendido == "Sim"){val++}
      if(ano == "1997"){val++}
      if(genêro == "metroidvania"){val++}
    }

    const porcentagem = (val / 5) * 100
    if(val == 5){
      setResposta(`Parabéns você acertou ${porcentagem}% do teste`)
      setSituacao("verde")
    }else if(val == 0){
      setResposta(`Infelimente você acertou ${porcentagem}% do teste`)
      setSituacao("vermelho")
    }else{
      setResposta(`Você fez ${porcentagem}% do teste`)
      setSituacao("amarelo")
    }
  }

  return (
    <>
      <img src="./img/logo.png" alt="" className='logo'/>
        <form onSubmit={handleSubmit(info)}>
          <div className={`quiz-container ${div}`}>
            <h2 className='titulo'>{titulo}</h2>
            <div className='design'>
              <img src={img} />
                  <div className='questões'>
                    <p>
                      <label htmlFor="nome">Qual o nome do protagonista:</label>
                      <input type="text" required className='campos' {...register("nome")}/>
                    </p>
                    <p>
                      <label htmlFor="plataforma">Em qual plataforma o jogo foi lançado:</label>
                      <select id="plataforma" {...register("plataforma")}>
                        <option id="PS1" value="PS1">PS1</option>
                        <option id="Game-boy" value="Game-boy">Game-boy</option>
                        <option id="DS" value="DS">DS</option>
                        <option id="TurboGrafx-16" value="TurboGrafx-16">TurboGrafx-16</option>
                        <option id="Mega Drive" value="Mega Drive">Mega Drive</option>
                      </select>
                    </p>
                      <p>
                      <label htmlFor="vendido">O jogo está entre os 10 mais vendidos da franquia?</label>
                      <div className='radio'>
                        <label>
                          <input type="radio" id="vendido" required {...register("vendido")} value="Sim"/>sim
                        </label>
                        <label>
                          <input type="radio" id="vendido" required {...register("vendido")} value="Não"/>Não
                        </label>
                      </div>
                     </p>
                    <p>
                      <label htmlFor="ano">Em que ano foi lançado o jogo:</label>
                      <input type="text" required className='campos' {...register("ano")}/>
                    </p>
                    <p>
                      <label htmlFor="genêro">Qual o gênero do jogo?</label>
                      <div className='radio'>
                        <label>
                          <input type="radio" id="jogo" required {...register("genêro")} value="metroidvania"/>metroidvania
                        </label>
                        <label>
                          <input type="radio" id="jogo" required {...register("genêro")} value="classicvania"/>classicvania
                        </label>
                      </div>
                    </p>
                    <p>
                      <input type="submit" value="Verificar Resultado" className='btn submit'/>
                    </p>
                    <h2 className={`${situacao}`}>{resposta}</h2>
                  </div>
            </div>
          </div>
        </form>
        <button className='btn reset' onClick={aleatorio}>Novo Quiz</button>
    </>
  )
  }

  export default App
